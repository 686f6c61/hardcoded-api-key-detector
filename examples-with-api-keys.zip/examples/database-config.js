// Database Configuration Example
// Contains various database connection strings (FOR TESTING ONLY)

// MongoDB with credentials
const mongodb_uri = "mongodb://admin:SuperSecret123@localhost:27017/myapp";

// PostgreSQL connection string
const postgres_uri = "postgresql://dbuser:dbpassword123@localhost:5432/production_db";

// MySQL connection
const mysql_connection = "mysql://root:MySecretPassword@localhost:3306/app_database";

// Redis connection
const redis_url = "redis://:myredispassword@localhost:6379";

// Supabase connection
const supabase_url = "postgresql://postgres:your-super-secret-password@db.abcdefghijklmnop.supabase.co:5432/postgres";

// Firebase Realtime Database
const firebase_uri = "https://my-app-12345.firebaseio.com";

module.exports = {
  mongodb_uri,
  postgres_uri,
  mysql_connection,
  redis_url,
  supabase_url,
  firebase_uri
};
