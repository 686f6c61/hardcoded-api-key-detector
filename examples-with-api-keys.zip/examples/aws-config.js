// AWS Configuration Example
// This file contains hardcoded AWS credentials (FOR TESTING ONLY)

const awsConfig = {
  // AWS Access Key - should be detected
  aws_access_key: "AKIAIOSFODNN7EXAMPLE",

  // AWS Secret Key - should be detected with context
  aws_secret_access_key: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",

  region: "us-east-1"
};

// Alternative configuration style
const AWS_ACCESS_KEY_ID = "AKIAJKLMNOPQRSTUVWXY";
const AWS_SECRET_KEY = "abcdefghijklmnopqrstuvwxyz1234567890ABCD";

module.exports = awsConfig;
