// Communication Services Tokens
// Slack, Discord, Telegram, Email services (FOR TESTING ONLY)

// Slack tokens
const slack_bot_token = "xoxb-1234567890123-1234567890123-abcdefghijklmnopqrstuvwx";
const slack_user_token = "xoxp-1234567890123-1234567890123-1234567890123-abcdefghijklmnopqrstuvwxyz123456";

// Discord bot token
const discord_bot_token = "MTA1MjM0NTY3ODkwMTIzNDU2Nzg.GaBcDe.FgHiJkLmNoPqRsTuVwXyZ1234567890AbCdEf";

// Telegram bot token
const telegram_bot_token = "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz-1234567890";

// SendGrid API Key
const sendgrid_api_key = "SG.abcdefghijklmnopqrst.1234567890abcdefghijklmnopqrstuvwxyz123456";

// Twilio credentials
const twilio_api_key = "SKabcdefghijklmnopqrstuvwxyz123456";
const twilio_auth_token = "1234567890abcdefghijklmnopqrstuvwx";

// Mailchimp API Key
const mailchimp_api_key = "1234567890abcdef1234567890abcdef-us12";

// Postmark Server Token
const postmark_token = "12345678-1234-1234-1234-123456789012";

module.exports = {
  slack_bot_token,
  discord_bot_token,
  telegram_bot_token,
  sendgrid_api_key,
  twilio_api_key,
  mailchimp_api_key,
  postmark_token
};
