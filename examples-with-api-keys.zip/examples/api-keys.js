// API Keys Example
// Multiple API keys from different services (FOR TESTING ONLY)

// OpenAI API Key
const openai_api_key = "sk-proj-abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOP";

// Anthropic Claude API Key
const anthropic_api_key = "sk-ant-api03-1234567890abcdefghijklmnopqrstuvwxyz1234567890abcdefghijklmnop";

// Google API Key
const google_api_key = "AIzaSyDaGmWKa4JsXZ-HjGw7ISLn_3namBGewQe";

// Stripe API Keys
const stripe_secret_key = "sk_live_51AbCdEfGhIjKlMnOpQrStUvWx";
const stripe_test_key = "sk_test_51AbCdEfGhIjKlMnOpQrStUvWx";

// GitHub Token
const github_token = "ghp_1234567890abcdefghijklmnopqrstuvwx";

// Stripe Publishable Key (public, should not be critical)
const STRIPE_PUBLISHABLE_KEY = "pk_live_51AbCdEfGhIjKlMnOpQrStUvWx";

module.exports = {
  openai_api_key,
  anthropic_api_key,
  google_api_key,
  stripe_secret_key,
  github_token
};
