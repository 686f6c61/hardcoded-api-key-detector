// AI/ML Service API Keys
// OpenAI, Anthropic, Hugging Face, etc. (FOR TESTING ONLY)

const config = {
  // OpenAI
  openai: {
    apiKey: "sk-proj-abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOP",
    organization: "org-1234567890abcdefghijklmnop"
  },

  // Anthropic Claude
  anthropic: {
    apiKey: "sk-ant-api03-1234567890abcdefghijklmnopqrstuvwxyz1234567890abcdefghijklmnop"
  },

  // Hugging Face
  huggingface_token: "hf_abcdefghijklmnopqrstuvwxyz1234",

  // Cohere
  cohere_api_key: "abcdefghijklmnopqrstuvwxyz1234567890AB",

  // Replicate
  replicate_api_key: "r8_abcdefghijklmnopqrstuvwxyz12",

  // ElevenLabs
  elevenlabs_api_key: "1234567890abcdef1234567890abcdef",

  // AssemblyAI
  assemblyai_api_key: "abcdef1234567890abcdef1234567890",

  // Deepgram
  deepgram_api_key: "1234567890abcdef1234567890abcdef12345678",

  // Pinecone
  pinecone_api_key: "12345678-1234-1234-1234-123456789012",

  // Mistral AI
  mistral_api_key: "abcdefghijklmnopqrstuvwxyz123456"
};

// Alternative style with context-aware variable names
const OPENAI_API_KEY = "sk-proj-XYZ123456789abcdefghijklmnopqrstuvwxyz1234567890ABCDEF";
const ANTHROPIC_API_KEY = "sk-ant-api03-TEST1234567890abcdefghijklmnopqrstuvwxyz1234567";

module.exports = config;
